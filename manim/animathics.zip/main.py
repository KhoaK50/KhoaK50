from manim import *
import random



class CreateCircle(Scene):
    def construct(self):
        circle = Circle()  # create a circle
        circle.set_fill(PINK, opacity=0.5)  # set the color and transparency
        self.play(Create(circle))  # show the circle on screen

class SquareToCircle(Scene):
    def construct(self):
        circle = Circle()  # create a circle
        circle.set_fill(PINK, opacity=0.5)  # set color and transparency

        square = Square()  # create a square
        square.rotate(PI / 4)  # rotate a certain amount

        self.play(Create(square))  # animate the creation of the square
        self.play(Transform(square, circle))  # interpolate the square into the circle
        self.play(FadeOut(square))  # fade out animation

class SquareAndCircle(Scene):
    def construct(self):
        circle = Circle()  # create a circle
        circle.set_fill(PINK, opacity=0.5)  # set the color and transparency

        square = Square()  # create a square
        square.set_fill(BLUE, opacity=0.5)  # set the color and transparency

        square.next_to(circle, RIGHT, buff=0.5)  # set the position
        self.play(Create(circle), Create(square))  # show the shapes on screen

class DifferentRotations(Scene):
    def construct(self):
        left_square = Square(color=BLUE, fill_opacity=0.7).shift(2 * LEFT)
        right_square = Square(color=GREEN, fill_opacity=0.7).shift(2 * RIGHT)
        self.play(
            left_square.animate.rotate(PI), Rotate(right_square, angle=PI), run_time=2
        )
        self.wait()

class TwoTransforms(Scene):
    def construct(self):
        a = Circle()
        t1 = Square()
        t2 = Triangle()
        self.play(Create(a))
        self.wait()
        for t in [t1,t2]:
            self.play(Transform(a,t))

class MobjectPlacement(Scene):
    def construct(self):
        circle = Circle()
        square = Square()
        triangle = Triangle()

        # place the circle two units left from the origin
        circle.move_to(LEFT * 2)
        # place the square to the left of the circle
        square.next_to(circle, LEFT)
        # align the left border of the triangle to the left border of the circle
        triangle.align_to(circle, LEFT)

        self.add(circle, square, triangle)
        self.wait(1)

class MobjectStyling(Scene):
    def construct(self):
        circle = Circle().shift(LEFT)
        square = Square().shift(UP)
        triangle = Triangle().shift(RIGHT)

        circle.set_stroke(color=GREEN, width=10)
        square.set_fill(YELLOW, opacity=1.0)
        triangle.set_fill(PINK, opacity=0.5)

        self.add(circle, square, triangle)
        self.wait(1)

class AnimateExample(Scene):
    def construct(self):
        square = Square().set_fill(RED, opacity=1.0)
        self.add(square) 

        # animate the change of color
        self.play(square.animate.set_fill(WHITE))
        self.wait(1)

        # animate the change of position and the rotation at the same time
        self.play(square.animate.shift(UP).rotate(PI / 4))
        self.wait(1)

class ExampleTransform(Scene):
    def construct(self):
        m1 = Square().set_color(RED)
        m2 = Rectangle().set_color(RED).rotate(0.2)
        self.play(Transform(m1,m2))
        self.play(FadeOut(m1))

class ShowScreenResolution(Scene):
    def construct(self):
        pixel_height = config["pixel_height"]  #  1080 is default
        pixel_width = config["pixel_width"]  # 1920 is default
        frame_width = config["frame_width"]
        frame_height = config["frame_height"]
        self.add(Dot())
        d1 = Line(frame_width * LEFT / 2, frame_width * RIGHT / 2).to_edge(DOWN)
        self.add(d1)
        self.add(Text(str(pixel_width)).next_to(d1, UP))
        d2 = Line(frame_height * UP / 2, frame_height * DOWN / 2).to_edge(LEFT)
        self.add(d2)
        self.add(Text(str(pixel_height)).next_to(d2, RIGHT))


class test(Scene):
    def construct(self):
        intro = Text(
            "BÀI TOÁN CHIA KẸO EULER", font="Times New Roman", color = BLUE, stroke_width= 2, stroke_color = WHITE, font_size = 60)
        self.play(Write(intro))

class CandyWithXeLaTeX(Scene):
    def construct(self):
        vn_template = TexTemplate()
        vn_template.add_to_preamble(r"\usepackage{ctex}")  # hỗ trợ tiếng Việt


        baitoan = Tex(
            r"Có $n$ \text{viên kẹo giống nhau}, và $k$ đứa trẻ $(n \ge k)$. "
            r"Hỏi có bao nhiêu cách để chia $n$ viên kẹo đó cho $k$ đứa trẻ, sao cho mọi đứa trẻ đều có kẹo?",
            tex_template=vn_template,
            font_size=36,
        )

        self.play(Write(baitoan))

class baitoanchiakeo(Scene):
    def construct(self):
        bacham = Text("...", font_size=40).to_edge(RIGHT)

        n = 7  # số lượng số 1
        ones = VGroup(*[
            Text("1", font_size=48) for _ in range(n)
        ]).arrange(RIGHT, buff=1.5).move_to(ORIGIN)

        self.play(LaggedStartMap(FadeIn, ones, lag_ratio=0.4))
        self.wait(0.1)
        self.play(FadeIn(bacham))
        self.wait(3)

        # Danh sách các màu
        colors = [RED, ORANGE, YELLOW, GREEN, BLUE, PURPLE, PINK]

        # Tạo các viên kẹo SVG với màu khác nhau
        candies = VGroup()
        for i, one in enumerate(ones):
            candy = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\candy.svg").scale(0.5)
            candy.move_to(one.get_center())

            # Tô màu từng phần của candy nếu có nhiều submobjects
            if len(candy.submobjects) > 0:
                for sub in candy.submobjects:
                    sub.set_fill(colors[i % len(colors)], opacity=1)
            else:
                candy.set_fill(colors[i % len(colors)], opacity=1)

            candies.add(candy)

        # Biến đổi từng số 1 thành kẹo màu
        self.play(
            LaggedStart(*[
                Transform(one, candy)
                for one, candy in zip(ones, candies)
            ], lag_ratio=0.4)
        )
        self.wait(2)

        group_sizes = [1, 2, 4] 

        assert sum(group_sizes) == n

        # Tô khung bao quanh mỗi nhóm kẹo
        start = 0
        boxes = VGroup()
        labels = VGroup()
        for i, size in enumerate(group_sizes):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font = "Times New Roman").next_to(box, DOWN)
            boxes.add(box)
            labels.add(label)
            start += size

        self.play(LaggedStartMap(Create, boxes, lag_ratio=0.3))
        self.play(LaggedStartMap(FadeIn, labels, lag_ratio=0.3))
        self.wait(0.5)

        new_group_sizes = [3, 1, 3]
        assert sum(new_group_sizes) == n

        # Tạo hộp và nhãn mới
        start = 0
        new_boxes = VGroup()
        new_labels = VGroup()
        for i, size in enumerate(new_group_sizes):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font="Times New Roman").next_to(box, DOWN)
            new_boxes.add(box)
            new_labels.add(label)
            start += size

        # Biến đổi hộp cũ và nhãn cũ sang hộp mới và nhãn mới
        self.play(
            *[Transform(boxes[i], new_boxes[i]) for i in range(len(new_boxes))],
            *[Transform(labels[i], new_labels[i]) for i in range(len(new_labels))]
        )
        self.wait(0.5)

        new_group_sizes1 = [2, 3, 2]
        assert sum(new_group_sizes1) == n

        # Tạo hộp và nhãn mới
        start = 0
        new_boxes1 = VGroup()
        new_labels1 = VGroup()
        for i, size in enumerate(new_group_sizes1):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font="Times New Roman").next_to(box, DOWN)
            new_boxes1.add(box)
            new_labels1.add(label)
            start += size

        # Biến đổi hộp cũ và nhãn cũ sang hộp mới và nhãn mới
        self.play(
            *[Transform(boxes[i], new_boxes1[i]) for i in range(len(new_boxes1))],
            *[Transform(labels[i], new_labels1[i]) for i in range(len(new_labels1))]
        )
        self.wait(0.5)

        new_group_sizes2 = [5, 1, 1]
        assert sum(new_group_sizes2) == n

        # Tạo hộp và nhãn mới
        start = 0
        new_boxes2 = VGroup()
        new_labels2 = VGroup()
        for i, size in enumerate(new_group_sizes2):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font="Times New Roman").next_to(box, DOWN)
            new_boxes2.add(box)
            new_labels2.add(label)
            start += size

        # Biến đổi hộp cũ và nhãn cũ sang hộp mới và nhãn mới
        self.play(
            *[Transform(boxes[i], new_boxes2[i]) for i in range(len(new_boxes2))],
            *[Transform(labels[i], new_labels2[i]) for i in range(len(new_labels2))]
        )
        self.wait(2)

        loibinhcandy = MathTex(r"C_{m-1}^{n-1}",font_size = 70, color = BLACK)
        boxloibinhcandy = SurroundingRectangle(loibinhcandy, color = WHITE, fill_color = WHITE, stroke_color = MAROON, fill_opacity = 1, buff = 2)
        self.play(FadeIn(boxloibinhcandy), FadeIn(loibinhcandy))

class Test2(Scene):
    def construct(self):
        # Vị trí các ngăn
        shelf_positions = [LEFT*5, LEFT*1.5, RIGHT*2, RIGHT*5.5]
        shelf_centers = []

        # Vẽ các ngăn và nhãn
        shelf_labels = []  # Tạo danh sách để lưu các nhãn "Ngăn"

        shelves = []
        for i, pos in enumerate(shelf_positions):
            shelf = Rectangle(height=2.5, width=2.4, color=WHITE).move_to(pos)
            label = Text(f"Ngăn {i+1}", font="Times New Roman", font_size=26).next_to(shelf, DOWN)

            self.play(Create(shelf), Write(label), run_time=2)

            shelves.append(shelf)
            shelf_centers.append(shelf.get_center())
            shelf_labels.append(label)  # Lưu nhãn vào danh sách

        self.wait(1)

        # Màu sách
        book_colors = [ORANGE, GOLD, PINK, PURPLE, RED, BLUE, TEAL, GREEN]

        # Danh sách các cách sắp xếp
        arrangements = [
            [2, 1, 2, 3],
            [3, 1, 3, 1],
            [1, 1, 4, 2],
            [1, 3, 2, 2],
            [2, 3, 1, 2],
            [1, 4, 2, 1],
            [2, 2, 2, 2],
            [4, 2, 1, 1],
            [1, 1, 2, 4],
            [2, 1, 4, 1],
            [3, 1, 1, 3],
            [1, 2, 1, 4],
            [1, 3, 1, 3],
            [2, 2, 3, 1],
            [1, 2, 3, 2],
        ]

        # Tạo 8 quyển sách cố định
        books = []
        for i in range(8):
            book = Rectangle(height=1.2, width=0.5,
                             fill_color=book_colors[i],
                             fill_opacity=1,
                             stroke_color=BLACK)
            books.append(book)

        # Hàm đặt vị trí sách theo cách xếp
        def get_book_targets(arrangement):
            targets = []
            idx = 0
            for shelf_idx, n_books in enumerate(arrangement):
                center = shelf_centers[shelf_idx]
                for i in range(n_books):
                    x_offset = -0.6 * (n_books - 1) / 2 + i * 0.6
                    target_pos = center + RIGHT * x_offset
                    targets.append(target_pos)
                    idx += 1
            return targets

        # Hiển thị ban đầu
        initial_arrangement = arrangements[0]
        targets = get_book_targets(initial_arrangement)

        for i, book in enumerate(books):
            book.move_to(DOWN * 4 + LEFT * 6 + i * RIGHT * 1.5)
            self.add(book)
        self.wait(2)

        animations = []
        for i, book in enumerate(books):
            animations.append(book.animate.move_to(targets[i]))
            self.play(*animations, run_time=1)


        phan1 = MathTex(r"x_1", font_size=70)
        phan2 = MathTex(r"x_2", font_size=70)
        phan3 = MathTex(r"x_3", font_size=70)
        phan4 = MathTex(r"x_4", font_size=70)
        phan1.next_to(shelves[0], UP) 
        phan2.next_to(shelves[1], UP)
        phan3.next_to(shelves[2], UP)
        phan4.next_to(shelves[3], UP)
        self.play(Write(phan1), Write(phan2), Write(phan3), Write(phan4), run_time=1)
        self.wait(2)
        equation1 = MathTex(r"x_1+x_2+x_3+x_4 = 8", font_size = 70).to_edge(UP, buff = 1)
        self.play(Transform(VGroup(phan1,phan2,phan3,phan4),equation1))

        # Các lần hoán đổi tiếp theo
        for i in range(1, len(arrangements)):
            arrangement = arrangements[i]
            targets = get_book_targets(arrangement)
            self.wait(0.3)

        # Di chuyển sách tới vị trí mới
            animations = []
            for j, book in enumerate(books):
                animations.append(book.animate.move_to(targets[j]))
            self.play(*animations, run_time=1)
            self.wait(0.3)
        self.wait(3)

        self.play(FadeOut(shelves[0]), FadeOut(books[0]), FadeOut(books[4]), FadeOut(books[5]), FadeOut(books[6]), FadeOut(books[7]),
                  FadeOut(shelves[1]), FadeOut(books[1]),
                  FadeOut(shelves[2]), FadeOut(books[2]),
                  FadeOut(shelves[3]), FadeOut(books[3])
                  )
        self.play(*[FadeOut(label) for label in shelf_labels])

        line1 = Text("Phương trình", font ="Times New Roman", font_size=40)
        line2 = MathTex(r"x_1 + x_2 + x_3 + x_4 = 8,", font_size=60)
        line3 = Text("Có bao nhiêu nghiệm nguyên dương?",font ="Times New Roman",  font_size=40)
        group = VGroup(line1, line2, line3).arrange(DOWN, aligned_edge=LEFT)
        box = always_redraw(lambda : SurroundingRectangle(group, color=MAROON, buff=0.3))
        loigiai1 = MathTex(r"C_{7}^{3} = 35",font_size = 70)
        loigiai2 = MathTex(r"8! \cdot C_{7}^{3} = 8! \cdot 35 = 1411200",font_size = 70)
        Dapan = MathTex(r"\dfrac{T}{600} = \dfrac{1411200}{600} = 2352",font_size = 70)
        boxloigiai = always_redraw(lambda : SurroundingRectangle(Dapan, color=MAROON, buff=0.3))




        self.play(Transform(VGroup(phan1,phan2,phan3,phan4), group))
        self.play(Create(box), run_time = 1.5)
        self.wait(2)
        self.play(FadeOut(VGroup(phan1,phan2,phan3,phan4)), FadeOut(box))
        self.wait(2)
        self.play(Create(loigiai1))
        self.wait(4)
        self.play(Transform(loigiai1, loigiai2))
        self.wait(2)
        self.play(Transform(loigiai1, Dapan))
        self.play(Create(boxloigiai), run_time = 1.5)
        self.wait(3)
        self.play(FadeOut(boxloigiai), FadeOut(loigiai1))
        self.wait(3)

class THPTQG(Scene):
    def construct(self):
        title = Text("Bài toán xếp sách", font = "Times New Roman",font_size=36, color=MAROON)
        line1 = Text("Có bốn ngăn (trong một giá để sách) được đánh số", font="Times New Roman", font_size=28)
        line2 = Text("thứ tự 1, 2, 3, 4 và tám quyển sách khác nhau.", font="Times New Roman", font_size=28)
        line3 = Text("Bạn An xếp hết tám quyển sách vào bốn ngăn đó", font="Times New Roman", font_size=28)
        line4 = Text("sao cho mỗi ngăn có ít nhất một quyển sách và", font="Times New Roman", font_size=28)
        line5 = Text("các quyển sách được xếp thẳng đứng thành một hàng.", font="Times New Roman", font_size=28)
        line6 = Text("Hai cách xếp được gọi là giống nhau nếu thỏa mãn:", font="Times New Roman", font_size=28)
        line7 = Text("• Mỗi ngăn có cùng số sách trong hai cách.", font="Times New Roman", font_size=28)
        line8 = Text("• Trong mỗi ngăn, thứ tự sách trái sang phải giống nhau.", font="Times New Roman", font_size=28)
        line9 = Text("Gọi T là số cách xếp đôi một khác nhau của An.", font="Times New Roman", font_size=28)
        line10 = Text("Tính giá trị của T chia cho 600.", font="Times New Roman", font_size=28)

        # Gom nhóm và căn chỉnh vị trí
        group = VGroup(
            title, line1, line2, line3, line4, line5,
            line6, line7, line8, line9, line10
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2).to_edge(LEFT).shift(RIGHT*0.5)

        # Viền xung quanh toàn bộ đề bài
        box = always_redraw(lambda: SurroundingRectangle(group, color=MAROON, buff=0.3))
        # Hiển thị
        self.play(Create(group), run_time = 2, rate_func = linear)
        self.wait(1)
        self.play(Create(box), run_time = 1.5)
        self.wait(2)
        self.play(FadeOut(group), FadeOut(box))
        self.wait(1)