from manim import *

Vtex = TexTemplateLibrary.vtex

class NumberBoxes(Scene):
    def construct(self):
        n = 9  # số phần tử (có thể thay đổi)
        mascot1 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model1(transparent).png").scale(0.4)
        mascot2 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model2(chamhoi)(transparent).png").scale(0.4)
        mascot3 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model3(hello)(moi)(transparent).png").scale(0.4)
        mascot4 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model4(tucgian)(transparent).png").scale(0.4)
        mascot5 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model5(vuive)(moi)(transparent).png").scale(0.4)
        mascot6 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model6(ngongac)(transparent).png").scale(0.4)
        mascot7 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model7(suyngam)(moi)(transparent).png").scale(0.4)

        #mod mascot
        mascot7.shift(DOWN*3 + RIGHT*5).scale(0.8)
        mascot5.shift(DOWN*3 + RIGHT*5).scale(0.8)

        # Các ô vuông
        boxes1 = VGroup()
        labels1 = VGroup()

        numbers1 = [r"1", r"1", r"1", r"1", r"\cdots", r"1", r"1", r"1", r"1"]

        for num in numbers1:
            square = Square(side_length=0.90, color=WHITE)
            label = MathTex(num, font_size=40).move_to(square.get_center())
            boxes1.add(square)
            labels1.add(label)

        group1 = VGroup(*[VGroup(b, l) for b, l in zip(boxes1, labels1)])
        group1.arrange(RIGHT, buff=0.3).scale(0.9)

        boxes0 = VGroup()
        labels0 = VGroup()
        numbers0 = [r"0", r"0", r"0", r"0", r"\cdots", r"0", r"0", r"0", r"0"]

        # Danh sách màu
        colors = [RED, ORANGE, YELLOW, GREEN, WHITE, PURPLE, PINK, TEAL, BLUE]

        for i, num in enumerate(numbers0):  # thêm i vào đây
            square = Square(side_length=0.83, color=colors[i % len(colors)])
            label = MathTex(num, font_size=40).move_to(square.get_center())
            boxes0.add(square)
            labels0.add(label)

        group0 = VGroup(*[VGroup(b, l) for b, l in zip(boxes0, labels0)])
        group0.arrange(RIGHT, buff=0.3).scale(0.9)


        brace = Brace(group1, direction = DOWN, buff = 0.3).next_to(group1, DOWN, buff = 0.3)
        chu = MathTex("n", font_size=60).next_to(brace, DOWN, buff = 0.3)
        brace0 = Brace(group0, direction = DOWN, buff = 0.3).next_to(group0, DOWN, buff = 0.3)
        chu0 = MathTex("k-1", font_size=60).next_to(brace0, DOWN, buff = 0.3)

        self.play(LaggedStart(*[Create(b) for b in boxes1], lag_ratio=0.3))
        self.play(LaggedStart(*[Write(l) for l in labels1], lag_ratio=0.3), Write(VGroup(brace, chu)))
        self.wait(1)
        self.play(VGroup(group1, brace, chu).animate.shift(UP*2.5))

        self.play(LaggedStart(*[Create(b) for b in boxes0], lag_ratio=0.2))
        self.play(LaggedStart(*[Write(l) for l in labels0], lag_ratio=0.2), Write(VGroup(brace0, chu0)))
        self.play(VGroup(group0, brace0, chu0).animate.shift(DOWN*1.5))
        self.wait(1)
        self.play(FadeOut(VGroup(brace, chu, brace0, chu0)))
        # self.play(VGroup(group1).animate.shift(DOWN*2))
        group1.save_state()
        group1_spaced = group1.copy().arrange(RIGHT, buff=1).scale(0.9)
        self.play(Transform(group1, group1_spaced))
        self.wait(1)

        gaps = []
        for i in range(len(group1) - 1):
            mid = (group1[i].get_right() + group1[i+1].get_left())/2
            gaps.append(mid)

        import random
        group0_filtered = [g for g in group0 if r"\cdots" not in g[1].get_tex_string()]


        for g in group0_filtered:
            g.save_state()


        for _ in range(4):
            zeros_to_move = random.sample(group0_filtered, len(gaps))
            animations = []
            for zero, target in zip(zeros_to_move, gaps):
                animations.append(zero.animate.move_to([target[0], group1[0].get_center()[1], 0]))

            self.play(*animations, run_time=1, rate_func=smooth)
            self.wait(0.3)

            # Chốt lại vị trí mới (thay vì restore về cũ)
            for g in group0_filtered:
                g.clear_updaters()
                g.save_state()
        self.wait(0.2)
        self.play(FadeOut(group0), FadeOut(group1))
        self.play(FadeIn(mascot7.shift(UP*2)))
        self.wait(2)
        

        equation1 = MathTex(r"C_{n-1}^{k-1}", font_size = 80)
        frame = SurroundingRectangle(equation1, color = MAROON, buff = 0.3)
        self.play(Write(equation1))
        self.wait(0.5)
        self.play(Write(frame), run_timne = 2, func_rate = linear)
        self.play(FadeOut(mascot7), FadeIn(mascot5.shift(UP*2)))
        self.play(
            ApplyMethod(
                mascot5.shift, UP*0.2, rate_func = there_and_back, run_time = 1
            )
        )
        self.wait(2)

class timetocook(Scene):
    def construct(self):
        mascot1 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model1(transparent).png").scale(0.4)
        mascot2 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model2(chamhoi)(transparent).png").scale(0.4)
        mascot3 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model3(hello)(moi)(transparent).png").scale(0.4)
        mascot4 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model4(tucgian)(transparent).png").scale(0.4)
        mascot5 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model5(vuive)(moi)(transparent).png").scale(0.4)
        mascot6 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model6(ngongac)(transparent).png").scale(0.4)
        mascot7 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model7(suyngam)(moi)(transparent).png").scale(0.4)

        mascot4.scale(1.3)
        mascot7.scale(1.3)
        mascot3.scale(1.3)
        text = Text("Time to cook", font = "Times New Roman", font_size = 60).next_to(mascot4, RIGHT).shift(UP*2)
        self.play(FadeIn(mascot4), run_time = 2)
        self.play(FadeIn(text), run_time = 2)
        self.wait(3)

        self.remove(mascot4, text)
        self.add(mascot7)
        self.wait(2)

        hinh1 = Square(side_length= 4, color = MAROON).next_to(mascot7, LEFT*2.2)
        hinh2 = Square(side_length= 4, color = MAROON).next_to(mascot7, RIGHT*2.2)

        self.play(Write(hinh1), Write(hinh2))
        self.wait(2)
        self.play(FadeIn(mascot3), FadeOut(mascot7))
        self.wait(3)
        self.play(FadeOut(hinh1), FadeOut(hinh2), FadeOut(mascot3))

class baitoanchiakeo(Scene):
    def construct(self):
        n = 7  # số lượng số 1
        mascot1 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model1(transparent).png").scale(0.4)
        mascot2 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model2(chamhoi)(transparent).png").scale(0.4)
        mascot3 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model3(hello)(moi)(transparent).png").scale(0.4)
        mascot4 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model4(tucgian)(transparent).png").scale(0.4)
        mascot5 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model5(vuive)(moi)(transparent).png").scale(0.4)
        mascot6 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model6(ngongac)(transparent).png").scale(0.4)
        mascot7 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model7(suyngam)(moi)(transparent).png").scale(0.4)
        ones = VGroup(*[
            Text("1", font_size=48) for _ in range(n)
        ]).arrange(RIGHT, buff=1.5).move_to(ORIGIN)

        self.play(LaggedStartMap(FadeIn, ones, lag_ratio=0.4))
        self.wait(1)

        # Danh sách các màu
        colors = [RED, ORANGE, YELLOW, GREEN, BLUE, PURPLE, PINK]

        # Tạo các viên kẹo SVG với màu khác nhau
        candies = VGroup()
        for i, one in enumerate(ones):
            candy = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\candy.svg").scale(0.5)
            candy.move_to(one.get_center())

            # Tô màu từng phần của candy nếu có nhiều submobjects
            if len(candy.submobjects) > 0:
                for sub in candy.submobjects:
                    sub.set_fill(colors[i % len(colors)], opacity=1)
            else:
                candy.set_fill(colors[i % len(colors)], opacity=1)

            candies.add(candy)

        # Biến đổi từng số 1 thành kẹo màu
        self.play(
            LaggedStart(*[
                Transform(one, candy)
                for one, candy in zip(ones, candies)
            ], lag_ratio=0.4)
        )
        self.wait(1)

        #Bài toán
        loi1 = MathTex(r"\text{Số cách chia }", r"7", r"\text{ viên kẹo cho }", r"3", r"\text{ bạn?}",tex_template = Vtex, font_size=68).to_edge(UP, buff=1)        
        frame1 = SurroundingRectangle(loi1, color = MAROON, buff = 0.3)
        self.play(LaggedStartMap(Write, loi1, lag_ratio=0.3))
        self.play(LaggedStartMap(Create, frame1, lag_ratio=0.3))
        self.wait(1)

        group_sizes = [1, 2, 4] 

        assert sum(group_sizes) == n

        # Tô khung bao quanh mỗi nhóm kẹo
        start = 0
        boxes = VGroup()
        labels = VGroup()
        for i, size in enumerate(group_sizes):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font = "Times New Roman").next_to(box, DOWN)
            boxes.add(box)
            labels.add(label)
            start += size

        self.play(LaggedStartMap(Create, boxes, lag_ratio=0.3))
        self.play(LaggedStartMap(FadeIn, labels, lag_ratio=0.3))
        self.wait(0.5)

        new_group_sizes = [3, 1, 3]
        assert sum(new_group_sizes) == n

        # Tạo hộp và nhãn mới
        start = 0
        new_boxes = VGroup()
        new_labels = VGroup()
        for i, size in enumerate(new_group_sizes):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font="Times New Roman").next_to(box, DOWN)
            new_boxes.add(box)
            new_labels.add(label)
            start += size

        # Biến đổi hộp cũ và nhãn cũ sang hộp mới và nhãn mới
        self.play(
            *[Transform(boxes[i], new_boxes[i]) for i in range(len(new_boxes))],
            *[Transform(labels[i], new_labels[i]) for i in range(len(new_labels))]
        )
        self.wait(0.5)

        new_group_sizes1 = [2, 3, 2]
        assert sum(new_group_sizes1) == n

        # Tạo hộp và nhãn mới
        start = 0
        new_boxes1 = VGroup()
        new_labels1 = VGroup()
        for i, size in enumerate(new_group_sizes1):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font="Times New Roman").next_to(box, DOWN)
            new_boxes1.add(box)
            new_labels1.add(label)
            start += size

        # Biến đổi hộp cũ và nhãn cũ sang hộp mới và nhãn mới
        self.play(
            *[Transform(boxes[i], new_boxes1[i]) for i in range(len(new_boxes1))],
            *[Transform(labels[i], new_labels1[i]) for i in range(len(new_labels1))]
        )
        self.wait(0.5)

        new_group_sizes2 = [5, 1, 1]
        assert sum(new_group_sizes2) == n

        # Tạo hộp và nhãn mới
        start = 0
        new_boxes2 = VGroup()
        new_labels2 = VGroup()
        for i, size in enumerate(new_group_sizes2):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font="Times New Roman").next_to(box, DOWN)
            new_boxes2.add(box)
            new_labels2.add(label)
            start += size

        # Biến đổi hộp cũ và nhãn cũ sang hộp mới và nhãn mới
        self.play(
            *[Transform(boxes[i], new_boxes2[i]) for i in range(len(new_boxes2))],
            *[Transform(labels[i], new_labels2[i]) for i in range(len(new_labels2))]
        )
        self.wait(0.5)

        new_group_sizes3 = [3, 1, 3]
        assert sum(new_group_sizes3) == n

        # Tạo hộp và nhãn mới
        start = 0
        new_boxes3 = VGroup()
        new_labels3 = VGroup()
        for i, size in enumerate(new_group_sizes3):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font="Times New Roman").next_to(box, DOWN)
            new_boxes3.add(box)
            new_labels3.add(label)
            start += size

        # Biến đổi hộp cũ và nhãn cũ sang hộp mới và nhãn mới
        self.play(
            *[Transform(boxes[i], new_boxes3[i]) for i in range(len(new_boxes3))],
            *[Transform(labels[i], new_labels3[i]) for i in range(len(new_labels3))]
        )
        self.wait(1)

        self.play(VGroup(ones, boxes, labels).animate.shift(UP*1), run_time = 1.5, func_rate = linear)
        self.wait(1.5)


        # loi1 = MathTex(r"\text{Số cách chia 7 viên kẹo cho 3 bạn?}", tex_template = Vtex, font_size = 68).to_edge(UP, buff = 1)

        loibinhcandy = MathTex(r"C_{7-1}^{3-1}",font_size = 80).shift(DOWN*2)
        loibinhcandy_final = MathTex(r"C_{7-1}^{3-1}", font_size=80).shift(DOWN*2)
        loibinhcandy_final1 = MathTex(r"C_{6}^{2}", font_size=80).shift(DOWN*2)
        a = MathTex(r"C_{6}^{2} = \dfrac{6!}{(6-2)!2!}", font_size=80).shift(DOWN*2+LEFT*0.8)
        b = MathTex(r"= 15", font_size = 80).arrange(RIGHT, buff = 0.3).next_to(a)
        a[0][1].set_color(ORANGE)
        a[0][2].set_color(TEAL)
        a[0][4].set_color(TEAL)
        a[0][8].set_color(TEAL)
        a[0][10].set_color(ORANGE)
        a[0][13].set_color(ORANGE)



        loibinhcandy_final[0][4].set_color(YELLOW)
        loibinhcandy_final[0][1].set_color(BLUE)

        self.play(Write(loibinhcandy))
        self.wait(1)

        num7 = loi1[1]   
        num3 = loi1[3]
        n_tex = loibinhcandy[0][4]   
        k_tex = loibinhcandy[0][1] 
        self.play(num7.animate.set_color(YELLOW).set_weight(BOLD),
                num3.animate.set_color(BLUE).set_weight(BOLD), 
                n_tex.animate.set_color(YELLOW).set_weight(BOLD), 
                k_tex.animate.set_color(BLUE).set_weight(BOLD))
        self.wait(1)

        self.play(
            ReplacementTransform(num7.copy(), loibinhcandy_final[0][4]),  
            ReplacementTransform(num3.copy(), loibinhcandy_final[0][1]),  
            Transform(loibinhcandy, loibinhcandy_final)                   
        )
        self.wait(0.6)
        self.remove(loibinhcandy_final[0][1])
        self.remove(loibinhcandy_final[0][4])
        self.play(Transform(VGroup(loibinhcandy), loibinhcandy_final1))
        self.wait(1)
        self.play(
            loibinhcandy_final1[0][1].animate.set_color(ORANGE).set_weight(BOLD),  
            loibinhcandy_final1[0][2].animate.set_color(TEAL).set_weight(BOLD)    
        )
        self.wait(1)
        self.remove(loibinhcandy_final1[0][1])
        self.remove(loibinhcandy_final1[0][2])
        self.play(Transform(loibinhcandy, a))
        self.wait(1.5)
        self.play(Write(b))
        self.wait(1)

        frame2 = SurroundingRectangle(VGroup(a,b), color = MAROON, buff =0.3)
        self.play(Create(frame2), run_time = 1.5, func_rate = linear)
        self.wait(2)
        self.play(FadeOut(VGroup(loibinhcandy, a,b,frame2)), FadeOut(boxes, labels), ones.animate.shift(DOWN*1))
        self.wait(1)

        self.play(
            LaggedStart(
                *[
                    Transform(one, candy.scale(0.6)) 
                    for one, candy in zip(ones, candies)
                ],
                lag_ratio=0.2
            )
        )
        self.wait(0.5)

        self.play(
            ones.animate.arrange(RIGHT, buff=0.6).move_to(ORIGIN).shift(LEFT*2.5),
            run_time=1.0
        )
        self.wait(0.5)


        # Tạo thêm dấu ba chấm và 3-4 viên kẹo bên phải dãy candies
        extra_dots = Text("...", font_size=48).next_to(one, RIGHT, buff=0.5)

        extra_candies = VGroup()
        for j in range(3):  # đổi 3 -> 4 nếu muốn thêm 4 viên
            c = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\candy.svg").scale(0.35)
            c.set_fill(colors[(j+len(candies)) % len(colors)], opacity=1)
            if j == 0:
                c.next_to(extra_dots, RIGHT, buff=0.6)
            else:
                c.next_to(extra_candies[j-1], RIGHT, buff=0.6)
            extra_candies.add(c)

        # Gom chung thành một dãy dài hơn
        all_candies = VGroup(candies, extra_dots, extra_candies)
        self.play(FadeIn(extra_dots), FadeIn(extra_candies))
        self.wait(0.5)

        loi2 = MathTex(r"\text{Số cách chia } n \text{ viên kẹo cho } k \text{ bạn?}", tex_template = Vtex, font_size = 68).to_edge(UP, buff = 1)
        self.play(Transform(loi1,loi2))
        self.wait(2)

        loi3 = MathTex(r"C_{n-1}^{k-1}",font_size = 80).shift(DOWN*2)
        frame3 = SurroundingRectangle(loi3, color = MAROON, buff = 0.3)
        self.play(Create(loi3))
        self.play(LaggedStart(*[Create(frame3)], lag_ratio= 0.2))

        mascot5.shift(RIGHT*4.5+DOWN*3).scale(0.5)

        self.play(FadeIn(mascot5))
        self.play(
            ApplyMethod(
                mascot5.shift, UP*0.2, rate_func = there_and_back, run_time = 1
            )
        )
        self.wait(2)

class Baitoan13(Scene):
    def construct(self):
        line2 = MathTex(r"x_1 + x_2 + \cdots + x_k = n, \quad n \geq k", font_size=70)
        line3 = Text("Có bao nhiêu nghiệm nguyên dương?",font ="Times New Roman",  font_size=40)
        group = VGroup(line2, line3).arrange(DOWN, aligned_edge=LEFT)
        box = always_redraw(lambda : SurroundingRectangle(group, color=MAROON, buff=0.3))
        nghiem = MathTex(r"x_i", font_size = 80) 
        SVG = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\kid.svg", fill_color = WHITE)
        nghiem1 = Text("thứ i", font = "Times New Roman", font_size = 36).next_to(SVG, RIGHT)


        self.play(Write(group), run_time = 4, rate_func = linear)
        self.wait(0.8)
        self.play(Create(box))
        self.wait(4)
        self.play(group.animate.shift(UP*2))
        self.wait(1)


        SVG1 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\kid.svg", fill_color = WHITE).scale(0.3)
        SVG2 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\kid.svg", fill_color = WHITE).scale(0.3)
        SVG3 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\kid.svg", fill_color = WHITE).scale(0.3)
        SVG4 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\kid.svg", fill_color = WHITE).scale(0.3)
        SVG5 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\kid.svg", fill_color = WHITE).scale(0.3)
        SVG6 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\kid.svg", fill_color = WHITE).scale(0.3)
        SVG7 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\kid.svg", fill_color = WHITE).scale(0.3)
        bacham = MathTex(r"\cdots", font_size = 48)

        so1 = MathTex(r"x_1").next_to(SVG1, UP, buff=0.2)
        so2 = MathTex(r"x_2").next_to(SVG2, UP, buff=0.2)
        so3 = MathTex(r"x_3").next_to(SVG3, UP, buff=0.2)
        so4 = MathTex(r"x_4").next_to(SVG4, UP, buff=0.2)
        so5 = MathTex(r"x_5").next_to(SVG5, UP, buff=0.2)
        so6 = MathTex(r"x_{k-1}").next_to(SVG6, UP, buff=0.2)
        so7 = MathTex(r"x_k").next_to(SVG7, UP, buff=0.2)
        Tonghop = VGroup(SVG1,SVG2,SVG3,SVG4,bacham, SVG5,SVG6,SVG7).arrange(RIGHT, buff = 0.8).shift(DOWN*2.4)
        labels = VGroup(
            MathTex("1", font_size = 30).next_to(SVG1, DOWN, buff=0.2),
            MathTex("2", font_size = 30).next_to(SVG2, DOWN, buff=0.2),
            MathTex("3", font_size = 30).next_to(SVG3, DOWN, buff=0.2),
            MathTex("4", font_size = 30).next_to(SVG4, DOWN, buff=0.2),
            MathTex("k-2", font_size = 30).next_to(SVG5, DOWN, buff=0.2),
            MathTex("k-1", font_size = 30).next_to(SVG6, DOWN, buff=0.2),
            MathTex("k", font_size = 30).next_to(SVG7, DOWN, buff=0.2),
        )
        pairs = [
            VGroup(SVG1, so1.next_to(SVG1, UP, buff=0.2), labels[0]),
            VGroup(SVG2, so2.next_to(SVG2, UP, buff=0.2), labels[1]),
            VGroup(SVG3, so3.next_to(SVG3, UP, buff=0.2), labels[2]),
            VGroup(SVG4, so4.next_to(SVG4, UP, buff=0.2), labels[3]),
            VGroup(SVG5, so5.next_to(SVG5, UP, buff=0.2), labels[4]),
            VGroup(SVG6, so6.next_to(SVG6, UP, buff=0.2), labels[5]),
            VGroup(SVG7, so7.next_to(SVG7, UP, buff=0.2), labels[6]),
    ]
        self.play(
            LaggedStart(
                FadeIn(pairs[0]),
                FadeIn(pairs[1]),
                FadeIn(pairs[2]),
                FadeIn(pairs[3]),
                FadeIn(bacham),
                FadeIn(pairs[4]),
                FadeIn(pairs[5]),
                FadeIn(pairs[6]),
                lag_ratio=2, run_time =6
            )
        )
        self.wait(2)
        Grouplon = VGroup(labels, pairs, Tonghop)
        frame = SurroundingRectangle(Grouplon, color = MAROON, buff = 0.3)
        self.play(Create(frame), run_time = 2, func_rate = linear)
        self.wait(2)




        loibinhcandy = Text("Đây chính là bài toán chia kẹo quen thuộc",font_size = 50, color = TEAL, font="Times New Roman")
        self.play(Write(loibinhcandy))
        self.wait(5)
    
        # boxloibinhcandy = SurroundingRectangle(loibinhcandy, color = WHITE, fill_color = WHITE, stroke_color = MAROON, fill_opacity = 1, buff = 1)
        equation = MathTex(r"C_{n-1}^{k-1}", font_size = 80, color = TEAL)     
        self.play(Transform(loibinhcandy, equation))
        self.wait(4)
        # self.play(FadeIn(boxloibinhcandy), FadeIn(loibinhcandy))
        # self.wait(2)
        # self.play(Transform(VGroup(loibinhcandy, boxloibinhcandy, nghiem, nghiem1, SVG), equation))
        # self.wait(3)

class chuyencanh(Scene):
    def construct(self):
        mascot1 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model1(transparent).png").scale(0.4)
        mascot2 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model2(chamhoi)(transparent).png").scale(0.4)
        mascot3 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model3(hello)(moi)(transparent).png").scale(0.4)
        mascot4 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model4(tucgian)(transparent).png").scale(0.4)
        mascot5 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model5(vuive)(moi)(transparent).png").scale(0.4)
        mascot6 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model6(ngongac)(transparent).png").scale(0.4)
        mascot7 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model7(suyngam)(moi)(transparent).png").scale(0.4)
        square1 = Square(side_length= 5, color = MAROON).shift(LEFT*4+DOWN*0.5)
        square2 = Square(side_length= 5, color = MAROON).shift(RIGHT*4+DOWN*0.5)
        bigprob = Text(" PROBLEM ", font = "Times New Roman", font_size = 40).next_to(square1, UP)
        smallprob = Text("PROBLEMS", font = "Times New Roman", font_size = 40).next_to(square2, UP)

        line = Line(
            square2.get_corner(UL), square2.get_corner(UR), color = MAROON
        ).shift(DOWN * 2.5)
        self.play(LaggedStart(*[Create(square1)], lag_ratio= 0.2))
        self.play(LaggedStart(*[Create(square2)], lag_ratio= 0.2), Create(line))
        self.wait(0.8)
        self.play(FadeIn(mascot3.scale(0.4)))
        self.wait(3)
        self.play(Write(bigprob))
        self.wait(3)
        self.play(Write(smallprob))
        self.wait(3)
        self.play(FadeOut(square1),FadeOut(square2),FadeOut(bigprob),FadeOut(smallprob), FadeOut(line))
        self.wait(0.5)
        self.play(mascot3.animate.scale(2.5).shift(DOWN*0.3))
        self.wait(1)

        text = Text("Dạng tổng quát hơn", font= "Times New Roman", font_size = 60).next_to(mascot3).shift(UP*3 + LEFT*5)
        frame = SurroundingRectangle(text, color = MAROON, buff = 0.2)
        self.play(Write(text), Create(frame))
        self.wait(2)
        self.play(FadeOut(frame), FadeOut(text), FadeOut(mascot3))
        self.wait(1)


        

        

