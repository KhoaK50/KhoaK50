from manim import *
Vtex = TexTemplateLibrary.vtex
class CreditTable(Scene):
    def construct(self):
        # texts = [
        #     [r"\text{Hoàng Khang}", r"\text{Âm thanh}"],
        #     [r"\text{Đăng Trí}", r"\text{Manim và xử lí video}"],
        #     [r"\text{Minh Huy}", r"\text{Manim và xử lí video}"],
        # ]

        # # Tham số bảng
        # n_rows = 3
        # n_cols = 2
        # cell_w = 5      # chiều rộng cột
        # cell_h = 1.5    # chiều cao hàng

        # # Tạo khung bảng
        # table_lines = VGroup()
        # # Đường dọc
        # for i in range(n_cols + 1):
        #     x = -cell_w * n_cols/2 + i * cell_w
        #     line = Line(
        #         [x, -n_rows*cell_h/2, 0],
        #         [x, n_rows*cell_h/2, 0],
        #         color=WHITE
        #     )
        #     table_lines.add(line)

        # # Đường ngang
        # for j in range(n_rows + 1):
        #     y = n_rows*cell_h/2 - j * cell_h
        #     line = Line(
        #         [-cell_w*n_cols/2, y, 0],
        #         [cell_w*n_cols/2, y, 0],
        #         color=WHITE
        #     )
        #     table_lines.add(line)

        # # Đặt nội dung vào ô
        # cells = VGroup()
        # for row in range(n_rows):
        #     for col in range(n_cols):
        #         txt = MathTex(
        #             texts[row][col],
        #             tex_template=Vtex
        #         ).scale(0.9)
        #         # Tính tọa độ tâm ô
        #         x = -cell_w/2 + col*cell_w
        #         y = n_rows/2*cell_h - row*cell_h - cell_h/2
        #         txt.move_to([x, y, 0])
        #         cells.add(txt)

        # table = VGroup(table_lines, cells)

        # self.play(Create(table))
        # self.wait(2)

        texts = [
            [r"\text{Hoàng Khang}", r"\text{Âm thanh}"],
            [r"\text{Đăng Trí}", r"\text{Manim và xử lí video}"],
            [r"\text{Minh Huy}", r"\text{Manim và xử lí video}"],
        ]

        n_rows = 3
        n_cols = 2
        total_w = 10      # tổng chiều rộng bảng
        cell_h = 1.5

        # chỉnh đường chia (qua trái 1)
        left_col_w = total_w/2 - 1
        right_col_w = total_w - left_col_w

        # Tính tọa độ cột
        x_left = -total_w/2
        x_mid = x_left + left_col_w
        x_right = x_left + total_w

        # Vẽ khung dọc
        table_lines = VGroup(
            Line([x_left, -n_rows*cell_h/2, 0], [x_left, n_rows*cell_h/2, 0]),
            Line([x_mid, -n_rows*cell_h/2, 0], [x_mid, n_rows*cell_h/2, 0]),
            Line([x_right, -n_rows*cell_h/2, 0], [x_right, n_rows*cell_h/2, 0]),
        )

        # Vẽ ngang
        for j in range(n_rows + 1):
            y = n_rows*cell_h/2 - j * cell_h
            table_lines.add(Line([x_left, y, 0], [x_right, y, 0]))

        # Đặt text
        cells = VGroup()
        for row in range(n_rows):
            # Cột trái
            txt_left = MathTex(texts[row][0], tex_template=Vtex).scale(1)
            x = (x_left + x_mid)/2
            y = n_rows/2*cell_h - row*cell_h - cell_h/2
            txt_left.move_to([x, y, 0])
            cells.add(txt_left)

            # Cột phải
            txt_right = MathTex(texts[row][1], tex_template=Vtex).scale(1)
            x = (x_mid + x_right)/2
            txt_right.move_to([x, y, 0])
            cells.add(txt_right)

        table = VGroup(table_lines, cells)

        self.play(Create(table))
        self.wait(2)