from manim import *
Vtex = TexTemplateLibrary.vtex

class test(Scene):
    def construct(self):
        a2 = MathTex(r"\text{Có bao nhiêu cách xếp } k-1 \text{ số 0 vào } n-1 \text{ khoảng trống?}", tex_template = Vtex, font_size=48)
        frame = SurroundingRectangle(a2, color = MAROON, buff =0.3)
        self.play(Write(a2))
        self.play(Create(frame), run_time = 1)
        self.wait(1)