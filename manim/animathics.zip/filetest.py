from manim import *

class BaiToanText(Scene):
    def construct(self):
        # Tiêu đề
        title = Text("Bài toán 1.1", font_size=36, color=MAROON)

        # Nội dung bài toán, chia làm nhiều dòng để xuống hàng
        line1 = Text("Có n viên kẹo giống nhau, và k đứa trẻ (n ≥ k).", font ="Times New Roman", font_size=28)
        line2 = Text("Hỏi có bao nhiêu cách để chia n viên kẹo đó cho",font ="Times New Roman",  font_size=28)
        line3 = Text("k đứa trẻ, sao cho mọi đứa trẻ đều có kẹo?",font ="Times New Roman",  font_size=28)

        # Căn chỉnh vị trí các dòng
        group = VGroup(title, line1, line2, line3).arrange(DOWN, aligned_edge=LEFT)
        box = SurroundingRectangle(group, color=MAROON, buff=0.3)

        # Hiển thị
        self.play(Create(VGroup(line1, line2, line3)))
        self.wait(2)
        self.play(Create(box))
