from manim import *
Vtex = TexTemplateLibrary.vtex
class CacNhaToanHoc(Scene):
    def construct(self):
        # Giới thiệu các nhà toán học nổi tiếng trước khi vô Euler
        # Dùng để đinh dạng phần ảnh
        image1 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\Pythagoras.jpg").scale(1.5).to_edge(UL)
        image2 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\euclid.jpg").scale(1.5).next_to(image1, RIGHT, buff = 1.4)
        image3 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\Fibonacci.jpg").scale(0.8).next_to(image2, RIGHT, buff = 1.4)
        image4 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\pascal.jpg").scale(1.6).next_to(image3, RIGHT, buff = 1.4)
        image5 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\newton.jpg").scale(0.4).to_edge(DL)
        image6 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\gauss.jpg").scale(1.5).next_to(image5, RIGHT, buff = 1.2)
        image7 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\viete.jpg").scale(1.5).next_to(image6, RIGHT, buff = 1.4)
        image8 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\Ramanujan.jpg").scale(0.6).next_to(image7, RIGHT, buff = 1.4)
        image9 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\illustration2.jpg").scale(2.4)
        image10 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\euler.jpg").scale(2.4)
        image11 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\recognition1.png").scale(4)
        image12 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\recognition2.jpg").scale(5)
        image13 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\regconition2(moi).png").scale(1.75)
        image14 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\regconition1(moi).png").scale(1.5)

        #ảnh mascot
        mascot1 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model1(transparent).png").scale(0.4)
        mascot2 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model2(chamhoi)(transparent).png").scale(0.4)
        mascot3 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model3(hello)(moi)(transparent).png").scale(0.4)
        mascot4 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model4(tucgian)(transparent).png").scale(0.4)
        mascot5 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model5(vuive)(moi)(transparent).png").scale(0.4)
        mascot6 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model6(ngongac)(transparent).png").scale(0.4)
        mascot7 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model7(suyngam)(moi)(transparent).png").scale(0.4)

        #mod cho ảnh mascot
        mascot2.to_corner(DR).shift(RIGHT*1.5+DOWN*1.5)
        mascot5.to_corner(DR).shift(RIGHT*1.5+DOWN*1.5)

        name = always_redraw(lambda : MathTex(r"\text{Leonhard Euler(1707 - 1783)}", tex_template = Vtex, font_size = 60).next_to(image10, UP, buff = 0.3))

        image = Group(image1, image2, image3, image4, image5, image6, image7, image8)


        # Dùng để đinh dạng phần ảnh (SVG)
        img_svg1 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\question.svg", fill_color = WHITE).next_to(image9, buff = 0.2).shift(UP*1).scale(0.5)
        img_svg2 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\question_nguoi.svg", fill_color = WHITE, stroke_color= WHITE).next_to(image9, LEFT, buff = 0.2).scale(1)
        img_svg3 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\crown.svg").next_to(image9, RIGHT + UP, buff = -1.4).scale(0.6).rotate(-PI/6)
        img_svg4 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\math1.svg", fill_color= WHITE).next_to(image9, LEFT, buff = 2).scale(0.6)

        # Phần Scene(animation) cho Cảnh đầu
        for img in [image1, image2, image3, image4, image5, image6, image7, image8]:
            self.play(FadeIn(img))
            self.wait(0.01)
        
        self.play(FadeOut(image))
        self.wait(0.5)

        self.play(FadeIn(image9), FadeIn(mascot2.shift(LEFT*2)))
        self.wait(3)
        self.play(FadeIn(image13), FadeOut(mascot2))
        self.remove(image9)
        self.wait(3)
        self.remove(image13)
        self.play(FadeIn(image14))
        self.wait(3)
        self.remove(image14)
        self.add(image9)
        self.wait(1)
        self.play(FadeIn(image10))
        self.wait(0.5)
        self.play(FadeIn(name), FadeIn(mascot5.shift(LEFT*2)))
        self.remove(image9)
        self.wait(3)
        self.play(FadeOut(name), FadeOut(image10), FadeOut(mascot5))
        self.wait(1)
        # self.play(FadeOut(image11) ,FadeOut(image12))
        # self.play(FadeIn(img_svg1), FadeIn(img_svg2))
        # self.wait(2)
        # self.play(FadeOut(img_svg1), FadeOut(img_svg2), FadeOut(image9))
        # self.play(FadeIn(image10))
        # self.wait(0.5)
        # self.play(FadeIn(img_svg3), FadeIn(img_svg4))
        # self.wait(4)
        # self.play(FadeOut(image10), FadeOut(img_svg3), FadeOut(img_svg4))
        

class GioiThieuEuler(Scene):
    def construct(self):
        # Dùng để đưa ra hình ảnh về Euler và một vài công thức tiêu biểu của ông
        # Hình ảnh (của dự án) và những dòng liên quan
        img = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\euler.jpg").scale(2.5)
        name = always_redraw(lambda : Tex("Leonhard Euler", font_size = 60).next_to(img, DOWN, buff = 0.5))
        SVG1 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\school.svg").next_to(img, LEFT, buff = 1).shift(UP)
        SVG2 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\student.svg", stroke_color= WHITE, fill_color= WHITE).next_to(SVG1, DOWN)
        intro = MathTex(r"\text{BÀI TOÁN CHIA KẸO EULER}", tex_template = Vtex ,font_size = 80).to_edge(UP, buff = 0.5)
        
        mascot6 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model6(ngongac)(transparent).png").scale(0.4)

        # Một vài công thức tiêu biểu của ông
        equation0 = MathTex(r"e = \lim_{n\to\infty }\left(1+\dfrac{1}{n} \right)^n", font_size=80)
        equation1 = MathTex(r"e^{i\theta} = \cos\theta + i\sin\theta", font_size=80)
        equation2 = MathTex(r"e^{i\pi}= -1", font_size = 80)
        equation3 = MathTex(r"V - E + F = 2", font_size = 80)
        equation4 = MathTex(r"\sum_{n=1}^{\infty} \dfrac{1}{n^2} = \dfrac{\pi^2}{6}", font_size = 80)
        equation5 = MathTex(r"\sum_{n=1}^{\infty} \dfrac{1}{n^s} = \prod \dfrac{1}{1 - p^{-s}}", font_size= 80)
        equation7 = MathTex(r"C_{m+n-1}^{n-1}", font_size = 80).rotate(PI/16).next_to(mascot6, LEFT, buff = 1)
        equation8 = MathTex(r"C_{m-1}^{n-1}", font_size = 80).rotate(-PI/16).next_to(mascot6, RIGHT, buff = 1)

        #ảnh mascot
        mascot1 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model1(transparent).png").scale(0.4)
        mascot2 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model2(chamhoi)(transparent).png").scale(0.4)
        mascot3 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model3(hello)(moi)(transparent).png").scale(0.4)
        mascot4 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model4(tucgian)(transparent).png").scale(0.4)
        mascot5 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model5(vuive)(moi)(transparent).png").scale(0.4)
        mascot7 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model7(suyngam)(moi)(transparent).png").scale(0.4)

        #mod anh
        # # Phần Scene(animation) cho Cảnh thứ 2
        # # Hiện ảnh và tên
        # self.play(FadeIn(img), FadeIn(name))
        # self.wait(2)

        # # Di chuyển ảnh + tên sang phải
        # self.play(img.animate.shift(LEFT * 4.5), run_time=1)
        # self.wait(1.5)  

        # Hiển thị công thức tiểu biểu của Euler và bài toán chia kẹo Euler
        self.play(Write(equation0), run_time =2)
        self.wait(1.5)
        self.play(Transform(equation0, equation1))
        self.wait(1.5)
        self.play(Transform(equation0, equation2))
        self.wait(2)
        self.play(Transform(equation0, equation4))
        self.wait(1.5)
        self.play(Transform(equation0, equation5))
        self.wait(1.5)
        # self.play(Transform(equation0, equation6))
        # self.wait(1.5)

        self.play(Transform(equation0, equation3))
        self.wait(3)
        self.play(FadeOut(equation0))
        self.wait(1)
        self.play(FadeIn(mascot6))
        self.wait(3)
        self.play(Write(equation7), Write(equation8))
        self.wait(3)
        self.play(Transform(VGroup(equation7, equation8), intro), mascot6.animate.shift(DOWN*1))
        self.wait(3)
        self.play(FadeOut(mascot6), FadeOut(intro), FadeOut(VGroup(equation7, equation8)))
        self.wait(2)
        # self.play(FadeOut(equation0))
        # self.play(img.animate.shift(RIGHT*4.5), run_time = 1)
        # self.wait(1)
        # self.play(FadeIn(SVG1), FadeIn(SVG2))
        # self.wait(2)
        # self.play(FadeIn(equation7), FadeIn(equation8))
        # self.wait(3)
        # self.play(Transform(VGroup(SVG1,SVG2, equation7, equation8), intro))
        # self.wait(3)
        # self.play(FadeOut(name), FadeOut(intro), FadeOut(img))
        # self.wait()

# class GeneratingFunctionIntro(Scene):
#     def construct(self):
#         title = Text("HÀM SINH TỔ HỢP CỦA EULER", font="Times New Roman", font_size=48)
#         self.play(Write(title))
#         self.wait(1)
#         self.play(title.animate.to_edge(UP))

#         question = Text("Có bao nhiêu cách chia 7 viên kẹo cho 3 đứa trẻ?", font="Times New Roman", font_size=40)
#         formula = MathTex(r"G(x) = \frac{1}{(1 - x)^3}")
#         expansion = MathTex(
#             r"= 1 + 3x + 6x^2 + 10x^3 + 15x^4 + 21x^5 + 28x^6 + 36x^7 + \dots"
#         )
#         explain = Text("Hệ số của x^7 là số cách chia 7 viên kẹo", font="Times New Roman", font_size=40).next_to(expansion, DOWN, buff = 0.5)

#         self.play(Write(question))
#         self.wait(1.5)
#         self.play(FadeOut(question))
#         self.play(Write(formula))
#         self.wait(1.5)
#         self.play(Transform(formula, expansion))
#         self.wait(2)
#         self.play(Write(explain))
#         self.wait(2)

# class CandyDistribution(Scene):
#     def construct(self):
#         title = Text("CÔNG THỨC CHIA KẸO TỔ HỢP", font="Times New Roman", font_size=48)
#         formula = MathTex(r"\binom{k + n - 1}{n - 1}")
#         label = Text("Chia $k$ viên kẹo cho $n$ đứa trẻ", font="Times New Roman", font_size=36)
#         example = MathTex(r"\binom{7 + 3 - 1}{3 - 1} = \binom{9}{2} = 36")
#         final = Text("Có 36 cách chia 7 viên cho 3 đứa trẻ", font="Times New Roman", font_size=36)


#         self.play(Write(title))
#         self.wait(1)
#         self.play(title.animate.to_edge(UP))
#         self.play(Write(formula))
#         self.wait(1)
#         self.play(Write(label.next_to(formula, DOWN)))
#         self.wait(2)
#         self.play(Transform(formula, example))
#         self.wait(2)
#         self.play(Write(final.next_to(example, DOWN)))
#         self.wait(3)

class CacBaiToan(Scene):
    def construct(self):
        tex_template = TexTemplate()
        tex_template.compiler = "xelatex"  # CỰC KỲ QUAN TRỌNG!
        tex_template.add_to_preamble(r"""
            \usepackage{fontspec}
            \setmainfont{Arial}
        """)
        # Phần media (chung + SVG)
        img = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\euler.jpg").scale(2.5).shift(LEFT*4.5)
        name = always_redraw(lambda : Tex("Leonhard Euler", font_size = 60).next_to(img, DOWN, buff = 0.5))
        SVG1 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\studenttalking.svg").next_to(img, LEFT, buff = 1).shift(UP)
        SVG2 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\candy.svg", stroke_color= WHITE, fill_color= WHITE).next_to(SVG1, DOWN)
        SVG3 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\candy2.svg").next_to(img, LEFT, buff = 1).shift(UP)
        SVG4 = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\bulb.svg", fill_color= YELLOW, stroke_color= WHITE).shift(UR*2).rotate(-PI/4)

        # Phần media dành cho ảnh thư viện
        img1 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\questionmeme.jpg").scale(3.5)
        img2 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\thesolution.jpg").scale(3.5)
        img3 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\questionmeme1.png").scale(3.5)


 
        # Nội dung bài toán
        # Bài toán 1.1
        title1 = Text("Bài toán 1.1", font_size=36, color=MAROON)
        line1 = Text("Có n viên kẹo giống nhau, và k đứa trẻ (n ≥ k).", font ="Times New Roman", font_size=28)
        line2 = Text("Hỏi có bao nhiêu cách để chia n viên kẹo đó cho",font ="Times New Roman",  font_size=28)
        line3 = Text("k đứa trẻ, sao cho mọi đứa trẻ đều có kẹo?",font ="Times New Roman",  font_size=28)
        group = VGroup(title1, line1, line2, line3).arrange(DOWN, aligned_edge=LEFT)
        box = always_redraw(lambda : SurroundingRectangle(group, color=MAROON, buff=0.3))

        # Bài toán 1.2
        dayso = Text("1111111...1111", font_size = 60)
        daysokhoangcach = Text("1_1_1_1_1_1_1_....._1_1_1_1", font_size = 60)
        brace_dayso = Brace(dayso, direction= DOWN, buff = 0.3).next_to(dayso, DOWN, buff = 0.3)
        label_dayso = always_redraw(lambda : Text("Có n số 1", font = "Times New Roman", font_size = 36).next_to(brace_dayso, DOWN, buff = 0.1))
        brace_daysokhoangcach = Brace(daysokhoangcach, direction= DOWN, buff = 0.3).next_to(daysokhoangcach, DOWN, buff = 0.3)
        label_daysokhoangcach = always_redraw(lambda : Text("Có n-1 khoảng cách", font = "Times New Roman", font_size = 36).next_to(brace_daysokhoangcach, DOWN, buff = 0.1))

        dayso0 = Text("0000000...0000", font_size = 40)
        dayso0khoangcach = Text("0_0_0_0_0_0_0_...0_0_0_0", font_size = 40)
        brace_dayso0 = Brace(dayso0, direction= DOWN, buff = 0.3).next_to(dayso0, DOWN, buff = 0.3)
        label_dayso0 = always_redraw(lambda : Text("Có k-1 số 0", font = "Times New Roman", font_size = 36).next_to(brace_dayso0, DOWN, buff = 0.1))

        daysokhoangcachchuan = Text("10101010101010.....01010101", font_size = 60)

        line4 = Text("Có bao nhiêu cách sắp xếp k-1 số 0 vào n-1 khoảng trống?", font ="Times New Roman", font_size=36)
        box1 = always_redraw(lambda : SurroundingRectangle(line4, color=MAROON, buff=0.3))
        equation1 = MathTex(r"C_{n-1}^{k-1}", font_size = 70)
        title2 = Text("Bài toán 1.2", font_size=36, color=MAROON)
        line5 = Text("Có bao nhiêu cách tạo một dãy nhị phân gồm n số 1 và k-1 số 0", font ="Times New Roman", font_size=28)
        line6 = Text("sao cho không có bất kì 2 số 0 nào đứng cạnh nhau và số 0",font ="Times New Roman",  font_size=28)
        line7 = Text("không đứng ở đầu hay cuối hàng?",font ="Times New Roman",  font_size=28)
        group1 = VGroup(title2, line5, line6, line7).arrange(DOWN, aligned_edge=LEFT)
        box2 = always_redraw(lambda : SurroundingRectangle(group1, color=MAROON, buff=0.3))

        # Chia hộp để so sánh hai bài toán 1.1 và 1.2
        # Bài toán 1.1 (phần chia)
        title1a = Text("Bài toán 1.1", font_size=36, color=MAROON)
        line1a = Text("Có n viên kẹo giống nhau, và k ", font ="Times New Roman", font_size=28)
        line2a = Text("đứa trẻ (n ≥ k). Hỏi có bao ",font ="Times New Roman",  font_size=28)
        line3a = Text("nhiêu cách để chia n viên kẹo ",font ="Times New Roman",  font_size=28)
        line4a = Text("đó cho k đứa trẻ sao cho mọi",font ="Times New Roman",  font_size=28)
        line5a = Text("sao cho mọi đứa trẻ đều có kẹo?",font ="Times New Roman",  font_size=28)
        group1a = VGroup(title1a, line1a, line2a, line3a, line4a, line5a).arrange(DOWN, aligned_edge=LEFT).shift(LEFT*3)
        box1a = always_redraw(lambda : SurroundingRectangle(group1a, color=MAROON, buff=0.3))

        # Bài toán 1.2 (phần chia)
        title1b = Text("Bài toán 1.2", font_size=36, color=MAROON)
        line1b = Text("Có bao nhiêu cách tạo một ", font ="Times New Roman", font_size=28)
        line2b = Text("dãy nhị phân gồm n số 1 và ",font ="Times New Roman",  font_size=28)
        line3b = Text("k-1 số 0 sao cho không có ",font ="Times New Roman",  font_size=28)
        line4b = Text("bất kì 2 số 0 nào đứng cạnh?",font ="Times New Roman",  font_size=28)
        line5b = Text("nhau và số 0 không đứng ở ",font ="Times New Roman",  font_size=28)
        line6b = Text("đầu hay cuối hàng?",font ="Times New Roman",  font_size=28)
        group1b = VGroup(title1b, line1b, line2b, line3b, line4b, line5b, line6b).arrange(DOWN, aligned_edge=LEFT)
        box1b = always_redraw(lambda : SurroundingRectangle(group1b, color=MAROON, buff=0.3))

        # LỜI BÌNH
        loibinh = Text("Hai bài toán này có mối liên hệ gì với nhau?", font = "TImes New Roman", color = BLACK, font_size = 40)
        boxloibinh = SurroundingRectangle(loibinh, color = WHITE, fill_color = WHITE, stroke_color = MAROON, fill_opacity = 1, buff = 0.4)


        # PHẦN ANIMATION
        # Phần animation cho bài 1.1
        self.play(Create(group), run_time = 5, rate_func = linear)
        self.wait(0.8)
        self.play(Create(box), run_time = 1.5, rate_func = smooth)
        self.wait(1.5)
        self.play(group.animate.shift(RIGHT *2))
        self.play(FadeIn(img), FadeIn(name))
        self.wait(3)
        self.play(FadeIn(img1))
        self.wait(4)
        self.play(FadeIn(img2))
        self.wait(3)
        self.play(FadeOut(img), FadeOut(name), FadeOut(group), FadeOut(box), FadeOut(img1), FadeOut(img2))
        self.wait(2)

        # Phần animation cho bài 1.2
        self.play(Create(dayso), run_time = 4, rate_func = linear)
        self.wait(1)
        self.play(Write(brace_dayso), run_time = 0.5, rate_func = smooth)
        self.play(Write(label_dayso))
        self.wait(1)
        self.play(VGroup(dayso,brace_dayso).animate.shift(UP*3), run_time = 1)
        self.wait(1)
        self.play(Create(dayso0), run_time = 4, rate_func = linear)
        self.wait(1)
        self.play(Write(brace_dayso0), run_time = 0.5, rate_func = smooth)
        self.play(Write(label_dayso0))
        self.wait(1)
        self.play(VGroup(dayso0, brace_dayso0).animate.shift(DOWN*2))
        self.wait(1)
        self.play(FadeOut(VGroup(dayso0, brace_dayso0, label_dayso0)), FadeOut(VGroup(dayso, brace_dayso, label_dayso)))
        self.play(FadeIn(img3), run_time = 3)
        self.wait(3)
        self.play(FadeIn(SVG4))
        self.wait(3)
        self.play(FadeOut(img3), FadeOut(SVG4))
        self.wait(0.5)
        self.play(Create(dayso), run_time = 2, rate_func = linear)
        self.wait(2)
        self.play(dayso.animate.shift(DOWN*3), run_time = 0.4)
        self.wait(1)
        self.play(Transform(dayso, daysokhoangcach))
        self.wait(2)
        self.play(Create(dayso0), run_time = 2)
        self.wait(3)
        self.play(Write(brace_daysokhoangcach), run_time = 0.5, rate_func = smooth)
        self.play(Write(label_daysokhoangcach))
        self.wait(2)
        self.play(
        FadeOut(dayso),
        FadeOut(label_daysokhoangcach),
        FadeOut(brace_daysokhoangcach),
        FadeOut(dayso0), run_time = 1
        )
        self.wait(2)
        self.play(Create(line4))
        self.wait(0.8)
        self.play(Create(box1), run_time = 1.5, rate_func = smooth)
        self.wait(2)
        self.play(line4.animate.shift(UP*3), run_time = 1)
        self.wait(0.5)
        self.play(Write(daysokhoangcachchuan), run_time = 1)
        self.wait(3)
        self.play(Transform(daysokhoangcachchuan, equation1), run_time = 1)
        self.wait(2)
        self.play(FadeOut(daysokhoangcachchuan), FadeOut(line4), FadeOut(box1))
        self.wait(2)
        self.play(Create(group1), run_time = 5, rate_func = linear)
        self.wait(0.8)
        self.play(Create(box2), run_time = 1.5, rate_func = smooth)
        self.wait(1.5)
        self.play(Transform(VGroup(group1, box2),VGroup(group1b, box1b).shift(RIGHT*3)))
        self.play(Create(group1a), run_time = 1, rate_func = linear)
        self.play(Create(box1a), run_time = 1.5, rate_func = smooth)
        self.wait(1)
        self.play(FadeIn(boxloibinh), FadeIn(loibinh), run_time = 1)
        self.wait(2)
        self.play(FadeOut(boxloibinh), FadeOut(loibinh), FadeOut(VGroup(group1a, box1a)), FadeOut(VGroup(group1, box2)), run_time=0.5)

class baitoanchiakeo(Scene):
    def construct(self):
        n = 7  # số lượng số 1
        ones = VGroup(*[
            Text("1", font_size=48) for _ in range(n)
        ]).arrange(RIGHT, buff=1.5).move_to(ORIGIN)

        self.play(LaggedStartMap(FadeIn, ones, lag_ratio=0.4))
        self.wait(2)

        # Danh sách các màu
        colors = [RED, ORANGE, YELLOW, GREEN, BLUE, PURPLE, PINK]

        # Tạo các viên kẹo SVG với màu khác nhau
        candies = VGroup()
        for i, one in enumerate(ones):
            candy = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\candy.svg").scale(0.5)
            candy.move_to(one.get_center())

            # Tô màu từng phần của candy nếu có nhiều submobjects
            if len(candy.submobjects) > 0:
                for sub in candy.submobjects:
                    sub.set_fill(colors[i % len(colors)], opacity=1)
            else:
                candy.set_fill(colors[i % len(colors)], opacity=1)

            candies.add(candy)

        # Biến đổi từng số 1 thành kẹo màu
        self.play(
            LaggedStart(*[
                Transform(one, candy)
                for one, candy in zip(ones, candies)
            ], lag_ratio=0.4)
        )
        self.wait(2)

        group_sizes = [1, 2, 4] 

        assert sum(group_sizes) == n

        # Tô khung bao quanh mỗi nhóm kẹo
        start = 0
        boxes = VGroup()
        labels = VGroup()
        for i, size in enumerate(group_sizes):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font = "Times New Roman").next_to(box, DOWN)
            boxes.add(box)
            labels.add(label)
            start += size

        self.play(LaggedStartMap(Create, boxes, lag_ratio=0.3))
        self.play(LaggedStartMap(FadeIn, labels, lag_ratio=0.3))
        self.wait(0.5)

        new_group_sizes = [3, 1, 3]
        assert sum(new_group_sizes) == n

        # Tạo hộp và nhãn mới
        start = 0
        new_boxes = VGroup()
        new_labels = VGroup()
        for i, size in enumerate(new_group_sizes):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font="Times New Roman").next_to(box, DOWN)
            new_boxes.add(box)
            new_labels.add(label)
            start += size

        # Biến đổi hộp cũ và nhãn cũ sang hộp mới và nhãn mới
        self.play(
            *[Transform(boxes[i], new_boxes[i]) for i in range(len(new_boxes))],
            *[Transform(labels[i], new_labels[i]) for i in range(len(new_labels))]
        )
        self.wait(0.5)

        new_group_sizes1 = [2, 3, 2]
        assert sum(new_group_sizes1) == n

        # Tạo hộp và nhãn mới
        start = 0
        new_boxes1 = VGroup()
        new_labels1 = VGroup()
        for i, size in enumerate(new_group_sizes1):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font="Times New Roman").next_to(box, DOWN)
            new_boxes1.add(box)
            new_labels1.add(label)
            start += size

        # Biến đổi hộp cũ và nhãn cũ sang hộp mới và nhãn mới
        self.play(
            *[Transform(boxes[i], new_boxes1[i]) for i in range(len(new_boxes1))],
            *[Transform(labels[i], new_labels1[i]) for i in range(len(new_labels1))]
        )
        self.wait(0.5)

        new_group_sizes2 = [5, 1, 1]
        assert sum(new_group_sizes2) == n

        # Tạo hộp và nhãn mới
        start = 0
        new_boxes2 = VGroup()
        new_labels2 = VGroup()
        for i, size in enumerate(new_group_sizes2):
            group = candies[start:start+size]
            box = SurroundingRectangle(group, color=WHITE, buff=0.3)
            label = Text(f"Bạn {i+1}", font_size=32, font="Times New Roman").next_to(box, DOWN)
            new_boxes2.add(box)
            new_labels2.add(label)
            start += size

        # Biến đổi hộp cũ và nhãn cũ sang hộp mới và nhãn mới
        self.play(
            *[Transform(boxes[i], new_boxes2[i]) for i in range(len(new_boxes2))],
            *[Transform(labels[i], new_labels2[i]) for i in range(len(new_labels2))]
        )
        self.wait(2)

        loibinhcandy = MathTex(r"C_{m-1}^{n-1}",font_size = 70, color = BLACK)
        boxloibinhcandy = SurroundingRectangle(loibinhcandy, color = WHITE, fill_color = WHITE, stroke_color = MAROON, fill_opacity = 1, buff = 2)
        self.play(FadeIn(boxloibinhcandy), FadeIn(loibinhcandy))

class Baitoan13(Scene):
    def construct(self):

        title = Text("Bài toán 1.3", font_size=36, color=MAROON)
        line1 = Text("Phương trình", font ="Times New Roman", font_size=28)
        line2 = MathTex(r"x_1 + x_2 + \cdots + x_k = n, \quad n \geq k", font_size=48)
        line3 = Text("Có bao nhiêu nghiệm nguyên dương?",font ="Times New Roman",  font_size=28)
        group = VGroup(title, line1, line2, line3).arrange(DOWN, aligned_edge=LEFT)
        box = always_redraw(lambda : SurroundingRectangle(group, color=MAROON, buff=0.3))
        nghiem = MathTex(r"x_i", font_size = 80) 
        SVG = SVGMobject(r"C:\Users\ADMIN\Desktop\Project_images\kid.svg", fill_color = WHITE).shift(RIGHT)
        nghiem1 = Text("thứ i", font = "Times New Roman", font_size = 36).next_to(SVG, RIGHT)


        self.play(Create(group), run_time = 4, rate_func = linear)
        self.wait(0.8)
        self.play(Create(box))
        self.wait(3)
        self.play(FadeOut(group), FadeOut(box))
        self.wait(1)
        self.play(FadeIn(nghiem))
        self.play(nghiem.animate.shift(LEFT*3), run_time = 0.5)
        self.wait(1)
        self.play(FadeIn(SVG), FadeIn(nghiem1))
        self.wait(3)
        
        loibinhcandy = Text("Đây chính là bài toán chia kẹo quen thuộc",font_size = 50, color = BLACK, font="Times New Roman")
        boxloibinhcandy = SurroundingRectangle(loibinhcandy, color = WHITE, fill_color = WHITE, stroke_color = MAROON, fill_opacity = 1, buff = 1)
        equation = MathTex(r"C_{n-1}^{k-1}", font_size = 70)        
        self.play(FadeIn(boxloibinhcandy), FadeIn(loibinhcandy))
        self.wait(2)
        self.play(Transform(VGroup(loibinhcandy, boxloibinhcandy, nghiem, nghiem1, SVG), equation))
        self.wait(3)

class THPTQG(Scene):
    def construct(self):
        title = Text("Bài toán xếp sách", font = "Times New Roman",font_size=36, color=MAROON)
        line1 = Text("Có bốn ngăn (trong một giá để sách) được đánh số", font="Times New Roman", font_size=28)
        line2 = Text("thứ tự 1, 2, 3, 4 và tám quyển sách khác nhau.", font="Times New Roman", font_size=28)
        line3 = Text("Bạn An xếp hết tám quyển sách vào bốn ngăn đó", font="Times New Roman", font_size=28)
        line4 = Text("sao cho mỗi ngăn có ít nhất một quyển sách và", font="Times New Roman", font_size=28)
        line5 = Text("các quyển sách được xếp thẳng đứng thành một hàng.", font="Times New Roman", font_size=28)
        line6 = Text("Hai cách xếp được gọi là giống nhau nếu thỏa mãn:", font="Times New Roman", font_size=28)
        line7 = Text("• Mỗi ngăn có cùng số sách trong hai cách.", font="Times New Roman", font_size=28)
        line8 = Text("• Trong mỗi ngăn, thứ tự sách trái sang phải giống nhau.", font="Times New Roman", font_size=28)
        line9 = Text("Gọi T là số cách xếp đôi một khác nhau của An.", font="Times New Roman", font_size=28)
        line10 = Text("Tính giá trị của T chia cho 600.", font="Times New Roman", font_size=28)

        # Gom nhóm và căn chỉnh vị trí
        group = VGroup(
            title, line1, line2, line3, line4, line5,
            line6, line7, line8, line9, line10
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2).to_edge(LEFT).shift(RIGHT*0.5)

        # Viền xung quanh toàn bộ đề bài
        box = always_redraw(lambda: SurroundingRectangle(group, color=MAROON, buff=0.3))
        # Hiển thị
        self.play(Create(group), run_time = 2, rate_func = linear)
        self.wait(1)
        self.play(Create(box), run_time = 1.5)
        self.wait(4)
        self.play(FadeOut(group), FadeOut(box))
        self.wait(1)



