from manim import *

class Bookshelf(Scene):
    def construct(self):
        shelf_width = 12
        shelf_height = 2.5
        num_compartments = 4

        frame = Rectangle(width=shelf_width, height=shelf_height, color=DARK_BROWN)
        compartments = VGroup()
        shelf_centers = []
        for i in range(num_compartments):
            x_left = -shelf_width/2 + i*(shelf_width/num_compartments)
            x_right = -shelf_width/2 + (i+1)*(shelf_width/num_compartments)
            center_x = (x_left + x_right) / 2
            shelf_centers.append([center_x, 0, 0])  # lưu tâm của mỗi ngăn

            if i < num_compartments - 1:  # kẻ đường chia (không kẻ ngoài cùng)
                line = Line(
                    start=[x_right, -shelf_height/2, 0],
                    end=[x_right, shelf_height/2, 0],
                    color=DARK_BROWN
                )
                compartments.add(line)

        bookshelf = VGroup(frame, compartments)
        self.play(Create(bookshelf))
        self.wait(2)

        shelf_labels = []
        for i, center in enumerate(shelf_centers):
            label = Text(f"Ngăn {i+1}", font="Times New Roman", font_size=26, color = TEAL).next_to([center[0], -shelf_height/2, 0], DOWN)
            shelf_labels.append(label)
            self.play(Write(label), run_time=0.5)

        self.wait(1)

        book_colors = [ORANGE, GOLD, PINK, PURPLE, RED, BLUE, TEAL, GREEN]

        # Các cách sắp xếp
        arrangements = [
            [2, 1, 2, 3],
            [3, 1, 3, 1],
            [1, 1, 4, 2],
            [1, 3, 2, 2],
            [2, 3, 1, 2],
            [1, 4, 2, 1],
            [2, 2, 2, 2],
            [4, 2, 1, 1],
            [1, 1, 2, 4],
            [2, 1, 4, 1],
            [3, 1, 1, 3],
            [1, 2, 1, 4],
            [1, 3, 1, 3],
            [2, 2, 3, 1],
            [1, 2, 3, 2],
        ]

        books = []
        for i in range(8):
            book = Rectangle(
                height=1.2, width=0.5,
                fill_color=book_colors[i],
                fill_opacity=1,
                stroke_color=BLACK
            )
            books.append(book)
        def get_book_targets(arrangement):
            targets = []
            for shelf_idx, n_books in enumerate(arrangement):
                center = shelf_centers[shelf_idx]
                for i in range(n_books):
                    x_offset = -0.6 * (n_books - 1) / 2 + i * 0.6
                    target_pos = [center[0] + x_offset, center[1], 0]
                    targets.append(target_pos)
            return targets


        initial_arrangement = arrangements[0]
        targets = get_book_targets(initial_arrangement)

        for i, book in enumerate(books):
            book.move_to(DOWN * 4 + LEFT * 6 + i * RIGHT * 1.5)
            self.add(book)
        self.wait(2)

        animations = [book.animate.move_to(targets[i]) for i, book in enumerate(books)]
        self.play(*animations, run_time=1)

        phan_labels = []
        for i in range(num_compartments):
            lbl = MathTex(f"x_{i+1}", font_size=48).next_to([shelf_centers[i][0], shelf_height/2, 0], UP)
            phan_labels.append(lbl)
        self.play(*[Write(lbl) for lbl in phan_labels])

        phan_labels_group = VGroup(*phan_labels).copy()

        self.wait(2)
        equation1 = MathTex(r"x_1+x_2+x_3+x_4 = 8", font_size=70).to_edge(UP, buff=1)
        frame_equation = SurroundingRectangle(equation1, color = MAROON, buff = 0.3)
        self.play(Write(equation1))
        self.play(Create(frame_equation))
        self.wait(1)

        for arrangement in arrangements[1:]:
            targets = get_book_targets(arrangement)
            self.wait(0.3)
            animations = [book.animate.move_to(targets[j]) for j, book in enumerate(books)]
            self.play(*animations, run_time=1)
            self.wait(0.3)

        self.wait(3)

        equation2 = MathTex(r"C_{n-1}^{k-1}", font_size =68).shift(DOWN*3)
        equation3 = MathTex(r"C_{8-1}^{4-1}", font_size = 68).shift(DOWN*3)
        equation4 = MathTex(r"C_{7}^{3}", font_size = 68).shift(DOWN*3)
        a1 = MathTex(r"C_{7}^{3} = \dfrac{7!}{(7-3)!3!}", font_size=58).shift(DOWN*3)
        a2 = MathTex(r"C_{7}^{3} = 35", font_size=58).shift(DOWN*3)


        self.play(Write(equation2))
        self.wait(3)
        glows = []
        for lbl in phan_labels:
            self.play(
                lbl.animate.scale(1.3).set_color(YELLOW),  
                run_time=0.3
            )
            self.play(
                lbl.animate.scale(1/1.3).set_color(WHITE), 
                run_time=0.3
            )
        self.wait(2)
        self.play(Transform(phan_labels_group, equation3), FadeOut(equation2))
        self.wait(1)
        self.play(Transform(phan_labels_group, equation4))
        self.wait(1)
        self.play(Transform(phan_labels_group, a1))
        self.wait(1)
        self.play(Transform(phan_labels_group, a2))
        self.wait(1)
        self.play(FadeOut(shelf_labels[0]), FadeOut(books[0]), FadeOut(books[4]), FadeOut(books[5]), FadeOut(books[6]), FadeOut(books[7]),
                  FadeOut(shelf_labels[1]), FadeOut(books[1]),
                  FadeOut(shelf_labels[2]), FadeOut(books[2]),
                  FadeOut(shelf_labels[3]), FadeOut(books[3]),
                  FadeOut(phan_labels[0]),FadeOut(phan_labels[1]),FadeOut(phan_labels[2]),FadeOut(phan_labels[3]), FadeOut(bookshelf), FadeOut(frame_equation), FadeOut(equation1)
                  )
        self.wait(1)

class tieptuctest2(Scene):
    def construct(self):
        mascot5 = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model5(vuive)(moi)(transparent).png").scale(0.3).to_corner(DR).shift(DOWN*5).flip(RIGHT)
        mascot5a = ImageMobject(r"C:\Users\ADMIN\Desktop\Project_images\model5(vuive)(moi)(transparent).png").scale(0.3).to_corner(DL).shift(DOWN*5)
        a2 = MathTex(r"C_{7}^{3}", r"=", r"35", font_size=58).shift(DOWN*3)
        self.add(a2)
        self.play(a2.animate.shift(UP*5),run_time = 2)
        self.wait(1)

        import random

        book_colors = [ORANGE, GOLD, PINK, PURPLE, RED, BLUE, TEAL, GREEN]
        books = [Rectangle(
                    height=1.2, width=0.5,
                    fill_color=book_colors[i],
                    fill_opacity=1,
                    stroke_color=BLACK
                ) for i in range(8)]
        book_row = VGroup(*books).arrange(RIGHT, buff=0.3)
        self.play(LaggedStart(*[FadeIn(book) for book in books], lag_ratio=0.1))
        self.wait(0.5)

        original_row = book_row.copy()

        for _ in range(3):  
            new_order = books[:]  # copy list gốc
            random.shuffle(new_order)  
            new_row = VGroup(*new_order).arrange(RIGHT, buff=0.3)
            self.play(Transform(book_row, new_row, run_time=1))
            self.wait(0.3)

        self.play(Transform(book_row, original_row, run_time=1.2))
        self.wait(2)

        equation1 = MathTex(r"8!", font_size = 58).shift(DOWN*2)
        equation2 = MathTex(r"8!" , r"=", r"8 \cdot 7 \cdot 6 \cdot 5 \cdot 4 \cdot 3 \cdot 2 \cdot 1", font_size = 58).shift(DOWN*2)
        equation3 = MathTex(r"8!", r"=", r"40320", font_size = 58).shift(DOWN*2)
        equation4 = MathTex(r"8!", r"\cdot", r"C_{7}^{3}", r"=", r"35", r"\cdot", r"40320", font_size = 58)
        equation5 = MathTex(r"8!", r"\cdot", r"C_{7}^{3}", r"=", r"1411200", font_size = 58)
        equation6 = MathTex(r"\dfrac{T}{600}", r"=", r"\dfrac{1411200}{600}",  r"=", r"2352", font_size = 58)

        frame = SurroundingRectangle(equation6, color = MAROON, buff = 0.3)


        self.play(Write(equation1))
        self.wait(2)
        self.play(ReplacementTransform(
            equation1[0], equation2[0]
        ))
        self.wait(0.2)
        self.play(Write(equation2[1:3]), run_time =0.8)
        self.wait(1)
        self.play(
            ReplacementTransform(equation1[0], equation3[0]),
            ReplacementTransform(equation2[1], equation3[1]),
            ReplacementTransform(equation2[2], equation3[2])
            )
        self.wait(2)
        self.play(FadeOut(book_row), equation3.animate.move_to(ORIGIN))    
        self.play(
            ReplacementTransform(equation3[0], equation4[0]),
            ReplacementTransform(equation3[2], equation4[6]),
            ReplacementTransform(equation3[1], equation4[3])
        )
        self.wait(0.5)
        self.play(
            ReplacementTransform(a2[0], equation4[2]),
            ReplacementTransform(a2[1], equation4[3].copy().set_opacity(0)),
            ReplacementTransform(a2[2], equation4[4])
        )
        self.play(Write(equation4[1]), Write(equation4[5]))
        self.wait(0.2)
        self.play(
            ReplacementTransform(equation4[0], equation5[0]),
            ReplacementTransform(equation4[1], equation5[1]),
            ReplacementTransform(equation4[2], equation5[2]),
            ReplacementTransform(equation4[3], equation5[3]),
            ReplacementTransform(equation4[4:7], equation5[4]),
        )
        self.wait(1)
        #equation6 = MathTex(r"\dfrac{T}{600}", r"=", r"\dfrac{1411200}{600}",  r"=", r"2352", font_size = 58).shift(DOWN*2)
        self.play(
            ReplacementTransform(equation5[0:3], equation6[0]),
            ReplacementTransform(equation5[3], equation6[1]),
            ReplacementTransform(equation5[4], equation6[2])
        )
        self.wait(0.2)
        self.play(Write(equation6[3:5]))
        self.wait(0.2)
        self.play(Create(frame))
        self.wait(1)
        self.play(mascot5.animate.shift(UP*4), mascot5a.animate.shift(UP*4))
        self.wait(3)



