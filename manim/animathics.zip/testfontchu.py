from manim import *
Vtex = TexTemplateLibrary.vtex

class test(Scene):
    def construct(self):
        a2 = MathTex(r"C_{7}^{3}", r"=", r"35", font_size=58).shift(UP*2)
        equation1 = MathTex(r"8!", font_size = 58).shift(DOWN*2)
        equation2 = MathTex(r"8!" , r"=", r"8 \cdot 7 \cdot 6 \cdot 5 \cdot 4 \cdot 3 \cdot 2 \cdot 1", font_size = 58).shift(DOWN*2)
        equation3 = MathTex(r"8!", r"=", r"40320", font_size = 58).shift(DOWN*2)
        equation4 = MathTex(r"8!", r"\cdot", r"C_{7}^{3}", r"=", r"35", r"\cdot", r"40320", font_size = 58).shift(DOWN*2)
        equation5 = MathTex(r"8!", r"\cdot", r"C_{7}^{3}", r"=", r"1411200", font_size = 58).shift(DOWN*2)
        # equation6 = MathTex(r"\dfrac{8! \cdot C_{7}^{3}}{600} = \dfrac{1411200}{600} = 2352", font_size = 58).shift(DOWN*2)

        #COOKING
        self.play(Write(equation1), Write(a2))
        self.wait(2)
        self.play(ReplacementTransform(
            equation1[0], equation2[0]
        ))
        self.wait(0.2)
        self.play(Write(equation2[1:3]), run_time =0.8)
        self.wait(1)
        self.play(
            ReplacementTransform(equation1[0], equation3[0]),
            ReplacementTransform(equation2[1], equation3[1]),
            ReplacementTransform(equation2[2], equation3[2])
            )
        self.wait(2)
        self.play(
            ReplacementTransform(equation3[0], equation4[0]),
            ReplacementTransform(equation3[2], equation4[6]),
            ReplacementTransform(equation3[1], equation4[3])
        )
        self.wait(0.5)
        self.play(
            ReplacementTransform(a2[0], equation4[2]),
            ReplacementTransform(a2[1], equation4[3]),
            ReplacementTransform(a2[2], equation4[4])
        )
        self.play(Write(equation4[1]), Write(equation4[5]))
        self.wait(0.2)
        self.play(
            ReplacementTransform(equation4[0], equation5[0]),
            ReplacementTransform(equation4[1], equation5[1]),
            ReplacementTransform(equation4[2], equation5[2]),
            ReplacementTransform(equation4[3], equation5[3]),
            ReplacementTransform(equation4[4:7], equation5[4]),
        )
        self.wait(1)
